  <?php
     session_start();


$k=$_SESSION['k'];


include 'db.php';




$un=$_SESSION['uname'];
$t_ins=$_SESSION['t_ins'];
$dept=$_SESSION['dept'];
$class=$_SESSION['yr'];
$ins=$_SESSION['ins'];
      $q = $_GET['q'];
?>	  
		  
		  
		  
		  <div class="table-responsive">
              <form action="ranks.php" method="post">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">S.no</th>
                    <th scope="col" class="sort" data-sort="budget">Title</th>
                    <th scope="col" class="sort" data-sort="status">Total Questions</th>
                    <th scope="col" class="sort" data-sort="status">Total Duration(in min)</th>
                    <th scope="col"  class="sort" data-sort="status">status</th>
                    <th></th>
                    <th scope="col" class="sort" data-sort="completion">Answer Key</th>
                    <th></th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody class="list">
                  <tr>
                    <?php

                     
                    date_default_timezone_set('Asia/Kolkata');
                    $today = date("Y-m-d"); 
                    $ttt=date('h:i:s');

                    if($t_ins=='school')
                     {

                    //$i=1;
                      if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);
                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                      
                     if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
					 }
                       
                       
                      
                     $y=mysqli_query($db,$sql);
					   
                     $count=mysqli_num_rows($y);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;
                     
					 
                     if($q!='')
                     {
                       $ql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_time<='$ttt'  and is_deleted like 'not deleted' ";
                        $y = mysqli_query($db,$ql);
                       $k=1;
                       
					 }
                   
					   

                     while( $r = mysqli_fetch_assoc($y))
                       { 
                        $aa=$r['ass_no'];
                         $sql="select * from result where un like $un and  ass_no like $aa" ;
  $x=mysqli_query($db,$sql);
  if(mysqli_num_rows($x)>0)
  {
while( $a = mysqli_fetch_assoc($x))
 {
  $marks=$a['marks_scored'];
  //$tot_m=$a['tot_m'];

}
}
else
{
  $marks=0;
}
                      

                          if($r['e_date']==$today and $ttt >= $r['e_time'])
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $stt=$r['s_time'];
                          $timestamp = strtotime($sts);
                          $sts = date("d-m-Y", $timestamp);
                          $status=$r['status'];
                           $tot_m=$no_qn * $r['mark'];
                         
                        
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>';?>
                        
              
               
                    
               <a href="#editModal" class="edit" data-toggle="modal">
              <i class="material-icons update" data-toggle="tooltip" 
             
              data-sts="<?php echo $sts; ?>"
              data-stt="<?php echo $stt; ?>"
             data-mark="<?php echo $marks; ?>"
             data-tot="<?php echo $tot_m; ?>"
             

         
              
              title="Edit"><button class="button button1"   style="vertical-align:middle">view</button></i>
            </a>
                       <?php
                           echo '</td>';

                  

                    ?>
                                         
                   
              
                      
                                         
                      
       <div id="editModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="update_form" action="edit_qns.php" method="post">
          <div class="modal-header">            
            <h4 class="modal-title">view details</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
       
            <br>
            
            
                 date of exam  
                  :   
                  <input type="date" name="dateexam" id='dateexam' disabled>  <br>
             
                 time of exam   
                  :   
                  <input type="time" name="timeexam" id='timeexam' disabled>  <br>
              
              marks scored  
                  :   
                 <input type="number" name="marks" id='marks' disabled >  <br>

               total marks
                  :   
                 <input type="number" name="tot" id='tot' disabled>  <br>
             
             
                
                <br>
                     
                     
                 
        </form>
      </div>
    </div>
  </div>


    

                     <td>
                     
                     <?php
                     if($status=='uploaded')
                     {
                        echo '<button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>Answer key </span></button>';
                     }
                     else
                     {
                               echo 'to be uploaded';
                     }

                      echo '         
                    </td><td></td>';
                    echo "</tr>";
                  }
                  else if($r['e_date']<$today )
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];

                          $timestamp = strtotime($sts);
                          $sts = date("d-m-Y", $timestamp);
                          $status=$r['status'];
                          $stt=$r['s_time'];

                        
                       echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                       
                       
                         
         <td>';?>
                        
              
               
                              <a href="#editModal" class="edit" data-toggle="modal">
              <i class="material-icons update" data-toggle="tooltip" 
             
              data-sts="<?php echo $sts; ?>"
              data-stt="<?php echo $stt; ?>"
             data-mark="<?php echo $marks; ?>"
             data-tot="<?php echo $tot_m; ?>"
             

         
              
              title="Edit"><button class="button button1"   style="vertical-align:middle">view</button></i>
            </a>
                       <?php
                           echo '</td>';

                  

                    ?>
                                         
                   
              
                      
                                         
                      
       <div id="editModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="update_form" action="edit_qns.php" method="post">
          <div class="modal-header">            
            <h4 class="modal-title">view details</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
       
            <br>
            
            
                 date of exam  
                  :   
                  <input type="date" name="dateexam" id='dateexam' disabled>  <br>
             
                 time of exam   
                  :   
                  <input type="time" name="timeexam" id='timeexam' disabled>  <br>
              
              marks scored  
                  :   
                 <input type="number" name="marks" id='marks'  disabled>  <br>

               total marks
                  :   
                 <input type="number" name="tot" id='tot' disabled>  <br>
             
             
                
                <br>
                     
                     
                 
        </form>
      </div>
    </div>
  </div>


    

                     <td><td>
                    <?php 
                     if($status=='uploaded')
                     {    
                      echo '<form action="answer_key.php "  method="post">
                       <button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>Answer key </span></button>
                       </form>';
                     }
                     else
                     {
                               echo 'to be uploaded';
                     }

                      echo '        
                        

                                  
                    </td><td></td>';
                    echo "</tr>";
                  }
                }
              }
              elseif($t_ins=='clg')
              {
                    
                  if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);
                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                
				if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
                       }
                      $y=mysqli_query($db,$sql);
                $count=mysqli_num_rows($y);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;

                      if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
                       }

                     $y=mysqli_query($db,$sql);
                    
                     while( $r = mysqli_fetch_assoc($y))
                       { 
                        $aa=$r['ass_no'];
                          $sql="select * from result where un like $un and  ass_no like $aa " ;
  $x=mysqli_query($db,$sql);
  if(mysqli_num_rows($x) > 0)
  {
while( $a = mysqli_fetch_assoc($x))
 {
  $marks=$a['marks_scored'];
  //$tot_m=$a['tot_m'];

   //echo '<script>console.log("hello")</script>';


}
}
else
{
  $marks=0;
  //$tot_m=0;
}

                          if($r['e_date']==$today and $ttt >= $r['e_time'])
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $stt=$r['s_time'];
                          $status=$r['status'];
                          $tot_m=$no_qn * $r['mark'];

                        
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                   
              
                           <td>';?>
                        
              
               
                    
                             <a href="#editModal" class="edit" data-toggle="modal">
              <i class="material-icons update" data-toggle="tooltip" 
             
              data-sts="<?php echo $sts; ?>"
              data-stt="<?php echo $stt; ?>"
             data-mark="<?php echo $marks; ?>"

             data-tot="<?php echo $tot_m; ?>"
             

         
              
              title="Edit"><button class="button button1"   style="vertical-align:middle">view</button></i>
            </a>
                       <?php
                           echo '</td>';

                  

                    ?>
                                         
                   
              
                      
                                         
                      
       <div id="editModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="update_form" action="edit_qns.php" method="post">
          <div class="modal-header">            
            <h4 class="modal-title">view details</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
       
            <br>
               
            
                 date of exam  
                  :   
                  <input type="date" name="dateexam" id="dateexam" disabled>  <br>
             
                 time of exam   
                  :   
                  <input type="time" name="timeexam" id="timeexam" disabled>  <br>
              
              marks scored  
                  :   
                 <input type="number" name="marks" id="marks"  disabled>  <br>

               total marks
                  :   
                 <input type="number" name="tot" id="tot" disabled>  <br>
             
             
                
                <br>
                     
                     
                 
        </form>
      </div>
    </div>
  </div>
                     
              


                     <td>
                     
                     <?php
                     if($status=='uploaded')
                     {
                        echo '<button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>Answer key </span></button>';
                     }
                     else
                     {
                               echo 'to be uploaded';
                     }

                      echo '         
                    </td><td></td>';
                    echo "</tr>";
                  }
                  elseif($r['e_date']<$today )
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $status=$r['status'];
                          $stt=$r['s_time'];
                          $tot_m=$no_qn * $r['mark'];

                        
                       echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                                           
                   <td> ';
                   ?>
                        
              
               
                             <a href="#editModal" class="edit" data-toggle="modal">
              <i class="material-icons update" data-toggle="tooltip" 
             
              data-sts="<?php echo $sts; ?>"
              data-stt="<?php echo $stt; ?>"
             data-mark="<?php echo $marks; ?>"
             data-tot="<?php echo $tot_m; ?>"
             

         
              
              title="view"><button class="button button1"   style="vertical-align:middle">view</button></i>
            </a>
                       <?php
                           echo '</td>';

                  

                    ?>
                                         
                   
              
                      
                                         
                      
       <div id="editModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="update_form" action="edit_qns.php" method="post">
          <div class="modal-header">            
            <h4 class="modal-title">view details</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
       
            <br>
            
            
                 date of exam  
                  :   
                  <input type="date" name="dateexam" id="dateexam" disabled>  <br>
             
                 time of exam   
                  :   
                  <input type="time" name="timeexam" id="timeexam" disabled>  <br>
              
              marks scored  
                  :   
                 <input type="number" name="marks" id="marks" disabled >  <br>

               total marks
                  :   
                 <input type="number" name="tot" id="tot" disabled>  <br>
             
             
                
                <br>
                     
                     
                 
        </form>
      </div>
    </div>
  </div>



    


                     <td><td>
                    <?php 
                     if($status=='uploaded')
                     {    
                      echo '<form action="answer_key.php "  method="post">
                        <button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>Answer key </span></button>
                        </form>';
                     }
                     else
                     {
                               echo 'to be uploaded';
                     }

                      echo '        
                        

                                  
                    </td><td></td>';
                    echo "</tr>";
                  }
                }
              }
              


              else
              {

                  if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);
                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                
				
				if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
                       }
				$y=mysqli_query($db,$sql);

                $count=mysqli_num_rows($y);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;
                   if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
                       }

                     $y=mysqli_query($db,$sql);

                     while( $r = mysqli_fetch_assoc($y))
                       { 
                        $aa=$r['ass_no'];
                     $sql="select * from result where un like $un and  ass_no like $aa " ;
  $x=mysqli_query($db,$sql);
  if(mysqli_num_rows($x) > 0)
  {
while( $a = mysqli_fetch_assoc($x))
 {
  $marks=$a['marks_scored'];
  //$tot_m=$a['tot_m'];

   //echo '<script>console.log("hello")</script>';


}
}
else
{
  $marks=0;
  //$tot_m=0;
}

                          if($r['e_date']==$today and $ttt >= $r['e_time'])
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                           $stt=$r['s_time'];
                          $status=$r['status'];
                          $tot_m=$no_qn * $r['mark'];
                        
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                   
                        
                         
              
                           <td>';?>
                        
              
               
                           <a href="#editModal" class="edit" data-toggle="modal">
              <i class="material-icons update" data-toggle="tooltip" 
             
              data-sts="<?php echo $sts; ?>"
              data-stt="<?php echo $stt; ?>"
             data-mark="<?php echo $marks; ?>"
             data-tot="<?php echo $tot_m; ?>"
             

         
              
              title="Edit"><button class="button button1"   style="vertical-align:middle">view</button></i>
            </a>
                       <?php
                           echo '</td>';

                  

                    ?>
                                         
                   
              
                      
                                         
                      
       <div id="editModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="update_form" action="edit_qns.php" method="post">
          <div class="modal-header">            
            <h4 class="modal-title">view details</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
       
            <br>
            
            
                 date of exam  
                  :   
                  <input type="date" name="dateexam" id="dateexam" disabled>  <br>
             
                 time of exam   
                  :   
                  <input type="time" name="timeexam" id="timeexam" disabled>  <br>
              
              marks scored  
                  :   
                 <input type="number" name="marks" id="marks" disabled >  <br>

               total marks
                  :   
                 <input type="number" name="tot" id="tot"  disabled>  <br>
             
             
                
                <br>
                     
                     
                 
        </form>
      </div>
    </div>
  </div>


    

                     <td>
                     
                     <?php
                     if($status=='uploaded')
                     {
                        echo '<button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>Answer key </span></button>';
                     }
                     else
                     {
                               echo 'to be uploaded';
                     }

                      echo '         
                    </td><td></td>';
                    echo "</tr>";
                  }
                  else if($r['e_date']<$today )
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $status=$r['status'];
                          $stt=$r['s_time'];

                        
                       echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                      
                       
                         
                           <td>';?>
                        
              
               
                    
                              <a href="#editModal" class="edit" data-toggle="modal">
              <i class="material-icons update" data-toggle="tooltip" 
             
              data-sts="<?php echo $sts; ?>"
              data-stt="<?php echo $stt; ?>"
             data-mark="<?php echo $marks; ?>"
             data-tot="<?php echo $tot_m; ?>"
             

         
              
              title="Edit"><button class="button button1"   style="vertical-align:middle">view</button></i>
            </a>
                       <?php
                           echo '</td>';

                  

                    ?>
                                         
                   
              
                      
                                         
                      
       <div id="editModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="update_form" action="edit_qns.php" method="post">
          <div class="modal-header">            
            <h4 class="modal-title">view details</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
       
            <br>
            
            
                 date of exam  
                  :   
                  <input type="date" name="dateexam" id="dateexam" disabled>  <br>

             
                 time of exam   
                  :   
                  <input type="time" name="timeexam" id="timeexam" disabled >  <br>
              
              marks scored  
                  :   
                 <input type="number" name="marks" id="marks" disabled >  <br>

               total marks
                  :   
                 <input type="number" name="tot" id="tot" disabled>  <br>
             
             
                
                <br>
                     
                     
                 
        </form>
      </div>
    </div>
  </div>
                     <td><td>
                    <?php 
                     if($status=='uploaded')
                     {    
                      echo '<form action="answer_key.php "  method="post">
                        <button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>Answer key </span></button>
                        </form>';
                     }
                     else
                     {
                               echo 'to be uploaded';
                     }

                      echo '        
                        

                                  
                    </td><td></td>';
                    echo "</tr>";
                  }
                }
              }
              
                  ?>
                    
                  </td></td>
                 <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td>
                    <form action="rank_individual.php "  method="post">
                   <button  class="button button1"   value="all"  name="but1" style="vertical-align:middle"><span>Overall Ranking</span></button>
                 </form>
                 </td>
                 <td></td>
                 <td></td>
                 <td></td>
                 <td></td>
                 </tr>

                </tbody>
              </table>
			               
            </form>
            </div>
            <!-- Card footer -->
            
          </div>
        </div>
      </div>
    </div>
  </div>