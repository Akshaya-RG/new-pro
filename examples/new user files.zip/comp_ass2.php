<?php
session_start();
error_reporting(E_ERROR | E_WARNING | E_PARSE);

$k=$_SESSION['k'];


include 'db.php';




$un=$_SESSION['uname'];
$t_ins=$_SESSION['t_ins'];
$dept=$_SESSION['dept'];
$class=$_SESSION['yr'];
$ins=$_SESSION['ins'];





$query="select * from user where un like '$un'";
  $y=mysqli_query($db,$query);
while( $r = mysqli_fetch_assoc($y))
 {
  $n=$r['un'];
  $m=$r['fn']." ".$r['ln'];
  $s=$r['pic'];
  $gen=$r['gender'];
}







?>
<html>

<head>
  <style type="text/css">
 .button1 {border-radius: 12px;}

  button {
  background-color: #5e72e4;
  color: white;
  border-radius:12px;
  padding: 14px 14px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.7;
}



/* Set a style for all buttons */
button {
  background-color: #9966ff;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  overflow: auto; /* Enable scroll if needed */
  display: flex;
  background-color: rgba(0,0,0,0.7); /* Black w/ opacity */
  text-align:right;
  padding-left:20px;
  padding-right:200px;
  padding-top: 200px;
  padding-bottom: 30px;
  display: hidden;
}

/* Modal Content/Box */
.modal-content {
 width: 500px;
 height: 300px;
 background-color: white;
 border radius: 4px;
 text-align: center;
 padding: 20px;
 position: relative;
}

/* The Close Button (x) */
.close {
  position: absolute;
  text-align: right;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 100px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}

body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color:#FFFFFF ;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 100px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 15px;
  color: #111;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #6A5ACD;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 100px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
body  {
  background-color: #fff;
 
}
img {
  border-radius: 50%;
}


input[type=text],input[type=date],input[type=time],input[type=number]{
 border:none;
}
</style>


  </style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Quiz</title>
  <!-- Favicon -->
  <link rel="icon" href="../assets/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="../assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="../assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <!-- Page plugins -->
  <!-- Argon CSS -->
  <link rel="stylesheet" href="../assets/css/argon.css?v=1.2.0" type="text/css">

</head>

<script src="on.js"></script>
<body  onunload="ajaxFunction()">
  <!-- Sidenav -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark border-bottom" style="background-color:black">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <!-- Search form -->
          
      <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" >&times;</a>
              <a class="nav-link active" href="dashboard2.php">
                <i class="ni ni-tv-2 text-primary"></i>
                <span class="nav-link-text">Dashboard</span>
              </a><br>
        <a class="nav-link" href="profile_user.php">
                <i class="ni ni-single-02 text-yellow"></i>
                <span class="nav-link-text">Profile</span>
              </a><br>
        <a class="nav-link" href="tables2.php">
                <i class="ni ni-bullet-list-67 text-default"></i>
                <span class="nav-link-text">scheduled  assessments</span>
              </a><br>
        <a class="nav-link" href="comp_ass2.php">
               <i class="ni ni-collection"  style="color:green;"></i>
                     
                <span class="nav-link-text">Completed assessments</span>
              </a><br>
        <a class="nav-link" href="ranks.php">
           
                    <i class="ni ni-chart-bar-32" style="color:red;"></i>
                    
                      <span  class="nav-link-text" > Ranking</span>
                 
              </a>
</div>
<span style="font-size:30px;color: #FFFFFF;cursor:pointer" onclick="openNav()" >&#9776; </span>
          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              
            </li>
           
       <div class="main-content" id="panel">
    <!-- Topnav -->
    
      
            
            
          </ul>
          <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
             <li>
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="media align-items-center">
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><i class="ni ni-single-02"></i>
                  <span>My profile</span></span>
                  </div>
                </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Welcome!</h6>
                </div>
               <a href="#!" class="dropdown-item">
                  <div class="media align-items-center">
                   <?php
                    if($gen=='male')
                    {
                      echo
                    '<span class="avatar avatar-sm rounded-circle">
                  

                    <img alt="Image placeholder" src="images/male.png">
                  </span>';
                }
                elseif($gen=='female')
                {
                  echo '<span class="avatar avatar-sm rounded-circle">
                  

                    <img alt="Image placeholder" src="images/female.png">
                  </span>';

                }
                else
                {
                   echo '<span class="avatar avatar-sm rounded-circle">
                  

                    <img alt="Image placeholder" src="images/'.$s.'>
                  </span>';

                }
                ?>
                 
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><?php echo $m; ?></span>
                  </div>
                </div>
            
                </a>
                <a href="#!" class="dropdown-item">
                  <i class="ni ni-badge"></i>
                  <span><?php echo $n; ?></span>
                </a>
                <a href="Change_pass.php" class="dropdown-item">
                  <i class="ni ni-settings-gear-65"></i>
                  <span>Settings</span>
                </a>
                 <a href="#!" class="dropdown-item">
                   <span class="badge badge-dot mr-4">
                        <i class="bg-success"  style=""></i>
                        <span class="status">&nbsp &nbsp status</span>
                      </span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="logout1.php" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
                 </div>
              </div>
            </li>
            
          </ul>
        </div>
      </div>
    </nav>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "750px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
    <!-- Header -->
    <!-- Header -->
    <div class="header bg-primary pb-6" style="background-image:url(images/bimage.jpeg);background-size: cover";>
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">User</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Completed ass</a></li>
                  
                </ol>
              </nav>
            </div>
            
          </div>
          <!-- Card stats -->
          
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
   <div class="row">
        <div class="col">
          <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <h2 class="mb-0">User</h2>
            
			</div>
			              <form class="navbar-search navbar-search-light form-inline mr-sm-3" id="navbar-search-main">
            <div class="form-group mb-0" >
              <div class="input-group input-group-alternative input-group-merge">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="fas fa-search"></i></span>
                </div>
                <input class="form-control" placeholder="Search" id="search" onkeyup="showUser(this.value)" type="text">
              </div>
            </div>
          </form>
                <div id="txtHint"><b></b></div>  
			       <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $('#search').keyup(function(){
      var search = $('#search').val();
      if(search.length == ''){
    $("#tab").show();
     $("#nnav").show(); 	
    }    
    else
    {
      $("#nnav").hide(); 
      $("#tab").hide(); 
    }

        });
    
function showUser(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","fetch.php?q="+str,true);
  xmlhttp.send();

  
}
</script>
          
		  <div id="result"></div>
            <!-- Light table -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

			
			
			
			
			<div class="table-responsive">
              <form  method="post">
              <table class="table align-items-center table-flush" id="tab">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">S.no</th>
                    <th scope="col" class="sort" data-sort="budget">Title</th>
                    <th scope="col" class="sort" data-sort="status">Total Questions</th>
                    <th scope="col" class="sort" data-sort="status">Total Duration(in min)</th>
                    <th scope="col"  class="sort" data-sort="status">status</th>
                    <th></th>
                    <th scope="col" class="sort" data-sort="completion">Answer Key</th>
                    <th></th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody class="list">
                  <tr>
                    <?php

                     
                    date_default_timezone_set('Asia/Kolkata');
                    $today = date("Y-m-d"); 
                    $ttt=date('H:i:s');

                    if($t_ins=='school')
                     {

                    //$i=1;
                      if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);
                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                      
                      $l="select * from post_ans where e_date <='$today'  and ins='$ins' and  class='$class' and gp='$dept'";
                     $y=mysqli_query($db,$l);

                     $count=mysqli_num_rows($y);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;

                     $l="select * from post_ans where e_date <='$today'  and ins='$ins' and  class='$class' and gp='$dept' limit $start,$per_page";

                     $y=mysqli_query($db,$l);


                     while( $r = mysqli_fetch_assoc($y))
                       { 
                        $aa=$r['ass_no'];
                         $sql="select * from result where un like $un and  ass_no like $aa" ;
  $x=mysqli_query($db,$sql);
  if(mysqli_num_rows($x)>0)
  {
while( $a = mysqli_fetch_assoc($x))
 {
  $marks=$a['marks_scored'];
  //$tot_m=$a['tot_m'];

}
}
else
{
  $marks=0;
}
                      

                          if(($r['e_date']==$today and $ttt >= $r['e_time']) or ($r['e_date']<$today ))
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $stt=$r['s_time'];
                          $timestamp = strtotime($sts);
                          $sts = date("d-m-Y", $timestamp);
                          $status=$r['status'];
                           $tot_m=$no_qn * $r['mark'];
                         
                        
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>';?>
                        
              
               
                    
               <a href="#editModal" class="edit" data-toggle="modal">
              <i class="material-icons update" data-toggle="tooltip" 
             
              data-sts="<?php echo $sts; ?>"
              data-stt="<?php echo $stt; ?>"
             data-mark="<?php echo $marks; ?>"
             data-tot="<?php echo $tot_m; ?>"
             

         
              
              title="Edit"><button class="button button1"   style="vertical-align:middle">view</button></i>
            </a>
                       <?php
                           echo '</td>';

                  

                    ?>
                                         
                   
              
                      
                                         
                      
       <div id="editModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="update_form" action="edit_qns.php" method="post">
          <div class="modal-header">            
            <h4 class="modal-title">view details</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
       
 <br>
                <label type="text" style="text-indent:50px;">DATE OF EXAM</label>&nbsp; :&nbsp;    <input type="date" name="dateexam" id="dateexam" style="text-indent:left" readonly ><br> 
                <label type="text" style="text-indent:-3em" >TIME OF EXAM</label>  : &nbsp; <input type="time" name="timeexam" id="timeexam" readonly><br>    
                 <label type="text" style="text-indent:63px"> MARKS SCORED</label> : &nbsp;<input type="number" name="marks" id="marks"  readonly>  <br> 
                 <label type="text" style="text-indent:63px"> TOTAL MARKS</label>  : &nbsp; <input type="number" name="tot" id="tot" readonly>  <br>
              <br>
                    
                     
                     
                 
        </form>
      </div>
    </div>
  </div>


    

                     <td>
                     
                     <?php
                            $files= scandir("answerkeys"); 
                     if($status=='not uploaded')
                     {
                      echo 'to be uploaded';
                        
                     }
                     else
                     {
                      echo '<button ><a style="color:white" download="'.$status.'" href="answerkeys/'.$status.'">Answer Key</a></button>'; 

                      echo '         
                    </td><td></td>';
                    echo "</tr>";
                  }
                 

                                  
                    
                }
              }
              }
              elseif($t_ins=='clg')
              {
                    
                  if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);
                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                $y=mysqli_query($db,"select * from post_ans where e_date <='$today' and ins='$ins' and yr='$class' and dept='$dept'");

                $count=mysqli_num_rows($y);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;

                     $l=" select * from post_ans where e_date <='$today' and ins='$ins' and yr='$class' and dept='$dept' limit $start,$per_page";

                     $y=mysqli_query($db,$l);
                    
                     while( $r = mysqli_fetch_assoc($y))
                       { 
                        $aa=$r['ass_no'];
                          $sql="select * from result where un like $un and  ass_no like $aa " ;
  $x=mysqli_query($db,$sql);
  if(mysqli_num_rows($x) > 0)
  {
while( $a = mysqli_fetch_assoc($x))
 {
  $marks=$a['marks_scored'];
  //$tot_m=$a['tot_m'];

   //echo '<script>console.log("hello")</script>';


}
}
else
{
  $marks=0;
  //$tot_m=0;
}

                          if(($r['e_date']==$today and $ttt >= $r['e_time']) or ($r['e_date']<$today ))
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $stt=$r['s_time'];
                          $status=$r['status'];
                          $tot_m=$no_qn * $r['mark'];

                        
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                   
              
                           <td>';?>
                        
              
               
                    
                             <a href="#editModal" class="edit" data-toggle="modal">
              <i class="material-icons update" data-toggle="tooltip" 
             
              data-sts="<?php echo $sts; ?>"
              data-stt="<?php echo $stt; ?>"
             data-mark="<?php echo $marks; ?>"

             data-tot="<?php echo $tot_m; ?>"
             

         
              
              title="Edit"><button class="button button1"   style="vertical-align:middle">view</button></i>
            </a>
                       <?php
                           echo '</td>';

                  

                    ?>
                                         
                   
              
                      
                                         
                      
       <div id="editModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="update_form" action="edit_qns.php" method="post">
          <div>            
            <h2 class="modal-title" >view details</h2>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
       
            <br>
                <label type="text" style="text-indent:50px;">DATE OF EXAM</label>&nbsp; :&nbsp;    <input type="date" name="dateexam" id="dateexam" style="text-indent:left" readonly ><br> 
                <label type="text" style="text-indent:-3em" >TIME OF EXAM</label>  : &nbsp; <input type="time" name="timeexam" id="timeexam" readonly><br>    
                 <label type="text" style="text-indent:63px"> MARKS SCORED</label> : &nbsp;<input type="number" name="marks" id="marks"  readonly>  <br> 
                 <label type="text" style="text-indent:63px"> TOTAL MARKS</label>  : &nbsp; <input type="number" name="tot" id="tot" readonly>  <br>
              <br>
                     
                     
                 
        </form>
      </div>
    </div>
  </div>
  </div>
                     
              


                     <td>
                     
                     <?php
                     $files= scandir("answerkeys"); 
                     if($status=='not uploaded')
                     {
                      echo 'to be uploaded';
                        
                     }
                     else
                     {
                      echo '<button ><a style="color:white" download="4.pdf" href="answerkeys/'.$status.'">Answer Key</a></button>'; 
                     }

                      echo '         
                    </td><td></td>';
                    echo "</tr>";
                  }
                  
		       
                }
              }


              else
              {

                  if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);
                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                $y=mysqli_query($db,"select * from post_ans where e_date <='$today' ");

                $count=mysqli_num_rows($y);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;

                     $l=" select * from post_ans where e_date <='$today'  limit $start,$per_page";

                     $y=mysqli_query($db,$l);

                     while( $r = mysqli_fetch_assoc($y))
                       { 
                        $aa=$r['ass_no'];
                     $sql="select * from result where un like $un and  ass_no like $aa " ;
  $x=mysqli_query($db,$sql);
  if(mysqli_num_rows($x) > 0)
  {
while( $a = mysqli_fetch_assoc($x))
 {
  $marks=$a['marks_scored'];
  //$tot_m=$a['tot_m'];

   //echo '<script>console.log("hello")</script>';


}
}
else
{
  $marks=0;
  //$tot_m=0;
}

                          if(($r['e_date']==$today and $ttt >= $r['e_time']) or ($r['e_date']<$today ))
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                           $stt=$r['s_time'];
                          $status=$r['status'];
                          $tot_m=$no_qn * $r['mark'];
                        
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                   
                        
                         
              
                           <td>';?>
                        
              
               
                           <a href="#editModal" class="edit" data-toggle="modal">
              <i class="material-icons update" data-toggle="tooltip" 
             
              data-sts="<?php echo $sts; ?>"
              data-stt="<?php echo $stt; ?>"
             data-mark="<?php echo $marks; ?>"
             data-tot="<?php echo $tot_m; ?>"
             

         
              
              title="Edit"><button class="button button1"   style="vertical-align:middle">view</button></i>
            </a>
                       <?php
                           echo '</td>';

                  

                    ?>
                                         
                   
              
                      
                                         
                      
       <div id="editModal" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <form id="update_form" action="edit_qns.php" method="post">
          <div class="modal-header">            
            <h4 class="modal-title">view details</h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
       
             <br>
                <label type="text" style="text-indent:50px;">DATE OF EXAM</label>&nbsp; :&nbsp;    <input type="date" name="dateexam" id="dateexam" style="text-indent:left" readonly ><br> 
                <label type="text" style="text-indent:-3em" >TIME OF EXAM</label>  : &nbsp; <input type="time" name="timeexam" id="timeexam" readonly><br>    
                 <label type="text" style="text-indent:63px"> MARKS SCORED</label> : &nbsp;<input type="number" name="marks" id="marks"  readonly>  <br> 
                 <label type="text" style="text-indent:63px"> TOTAL MARKS</label>  : &nbsp; <input type="number" name="tot" id="tot" readonly>  <br>
              <br>
                    
                     
                     
                 
        </form>
      </div>
    </div>
  </div>


    

                     <td>
                     <?php  $files= scandir("answerkeys"); ?>
                     <?php
                     if($status=='not uploaded')
                     {
                      echo 'to be uploaded';
                       
                     }
                     else
                     {
                      echo '<button ><a style="color:white" download="4.pdf" href="answerkeys/'.$status.'">Answer Key</a></button>';    
                     }

                      echo '         
                    </td><td></td>';
                    echo "</tr>";
                  }


                                  

                }
              }
              
                  ?>
                    
                  </td></td>
                 <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td>
                    <form action="rank_individual.php "  method="post">
                   <button  class="button button1"   value="all"  name="but1" style="vertical-align:middle"><span>Overall Ranking</span></button>
                 </form>
                 </td>
                 <td></td>
                 <td></td>
                 <td></td>
                 <td></td>
                 </tr>

                </tbody>
              </table>
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
              <script>
                $(document).on('click','.update',function(e) {
      
   var sts = $(this).attr("data-sts");
   var stt= $(this).attr("data-stt");
   var mark =$(this).attr("data-mark");
  var tot =$(this).attr("data-tot");
  console.log(sts);
  console.log(stt);
  console.log(mark);
  console.log(tot);

   
     $('#dateexam').val(sts);
     $('#timeexam').val(stt);
     $('#marks').val(mark);
      $('#tot').val(tot);

     
    
  });

              </script>
               <nav aria-label="Page navigation example" id="nnav">
  <ul class="pagination justify-content-end">
    <li 
    <?php
       if($page==1)
       {
         echo "class='page-item disabled'";
       }  
       else{
         echo "class='page-item'";
       }
    ?>
    >
      <a class="page-link" href="comp_ass2.php?page=<?php echo $page-1; ?>" tabindex="-1">
        <i class="fa fa-angle-left"></i>
      </a>
    </li>
    <?php
      for($i=1;$i<=$no_of_page;$i++)
      {
        ?>
           <li
            <?php 
              if($page==$i)
              {
              echo "class='page-item active'";
              }
              else{
                echo "class='page-item'";
              }

            ?>
           ><a class="page-link" href="comp_ass2.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
        <?php
      }
    ?>
   
    <li 
    <?php
       if($page==$no_of_page)
       {
         echo "class='page-item disabled'";
       }  
       else{
         echo "class='page-item'";
       }
    ?>
    >
      <a class="page-link" href="comp_ass2.php?page=<?php echo $page+1; ?>">
        <i class="fa fa-angle-right"></i>
        
      </a>
    </li>
  </ul>
</nav>
            </form>
            </div>
            <!-- Card footer -->
            
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="../assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="../assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="../assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="../assets/js/argon.js?v=1.2.0"></script>
  
  
</body>

</html>