              <?php
     session_start();


$k=$_SESSION['k'];


include 'db.php';




$un=$_SESSION['uname'];
$t_ins=$_SESSION['t_ins'];
$dept=$_SESSION['dept'];
$class=$_SESSION['yr'];
$ins=$_SESSION['ins'];
      $q = $_GET['q'];
?>	  
			
			
			
			
			
			
			
			<div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">sno</th>
                    <th scope="col" class="sort" data-sort="budget">title</th>
                    <th scope="col" class="sort" data-sort="status">total questions</th>
                    <th scope="col" class="sort" data-sort="status">total duration(in min)</th>
                    <th scope="col">status</th>
					<th></th>
					<th scope="col" class="sort" data-sort="completion">Option</th>
                    <th></th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody class="list">
                  <tr>
                      <form action="resultview.php"  method="post">
                    <?php
                    /*$cnt = mysqli_num_rows(mysqli_query($db,"SELECT * FROM post_ans"));
                    $row= $cnt+1;
                    $_SESSION['ass_no']=$row;*/
                    date_default_timezone_set('Asia/Kolkata');
                    $today = date("Y-m-d"); 
                    $ttt= date('H:i:s');
               
                    
                    if($t_ins=='school')
                    {
                    //$i=1;
                       if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);
                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                     if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
					 }
                     $y=mysqli_query($db,$sql);
                       $count=mysqli_num_rows($y);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;
					 if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
					 }

                     $y=mysqli_query($db,$sql);



                     while( $r = mysqli_fetch_assoc($y))
                       {  
                        $aa=$r['ass_no'];
                        $a="select ass_no, un from result where un='$un' and ass_no='$aa' ";
                         if(mysqli_num_rows(mysqli_query($db,$a))==0)
                         {
                          if($r['s_date']==$today and $ttt < $r['s_time'])
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                        $timestamp = strtotime($sts);
                        $sts = date("d/m/Y", $timestamp);
                        echo ' 
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on<br> '.$sts.'</span>
                    </td>
                    <td></td>
                     <td>
                     <label class="button button1"  name="but1" style="vertical-align:middle"><span> Test will start soon</span></label> </td>
                    
                                         
                      </div>
                    </td>';
                    echo "</tr>";
                  }
                 else if($r['s_date']>$today )
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $timestamp = strtotime($sts);
                     $sts = date("d/m/Y", $timestamp);
                        
                        echo ' 
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on <br> '.$sts.'</span>
                    </td>
                    <td></td>
                     <td>
                        <label class="button button1" name="but1" style="vertical-align:middle"><span> Test will start soon</span></label> </td>
                                         
                      </div>
                    </td>';
                    echo "</tr>";
					
                          }

                      else if(($r['s_date']==$today and $ttt >= $r['s_time']) and ( $r['e_date']==$today and $ttt <=$r['e_time'] ))
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $etime=$r['e_time'];
                           $timestamp = strtotime($sts);
                        $sts = date("d/m/Y", $timestamp);
                        echo ' 
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on<br> '.$sts.'</span>
                    </td>
                    <td></td>
                    
                     <td>
                      <div>
                     <button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>start test</span></button> 
                                         
                      </div>
                      </td>';
                    echo "</tr>";
                  }

                  else if( $today>$r['s_date'] and $today<=$r['e_date'])
                  {
                    
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $etime=$r['e_time']; $timestamp = strtotime($sts);
                        $sts = date("d/m/Y", $timestamp);
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on<br> '.$sts.'</span>
                    </td>
                    <td></td>
                    
                  
                      <td>
                      <div>
                     <button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>start test</span></button> 
                     </td>
                                         
                      </div>
                    ';
                    echo "</tr>";
                  
                  }


                       }
                 			 }
                      }
                      
                      elseif ($t_ins=='clg')

                    {
                      if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);


                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                    if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
					 }
                     $y=mysqli_query($db,$sql);


                       $count=mysqli_num_rows($y);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;
                      if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
					 }

                     $y=mysqli_query($db,$sql);
                         
                    
                    
                     while( $r = mysqli_fetch_assoc($y))
                     {   $aa=$r['ass_no'];
                        $a="select ass_no, un from result where un='$un' and ass_no='$aa' ";
                         if(mysqli_num_rows(mysqli_query($db,$a))==0)
                         {
                 
                   if($r['s_date']==$today and $ttt < $r['s_time'])
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                        $timestamp = strtotime($sts);
                     $sts = date("d/m/Y", $timestamp);
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on<br> '.$sts.'</span>
                    </td>
                    <td></td>
                     <td>
                        <label class="button button1"  name="but1" style="vertical-align:middle"><span> Test will start soon</span></label> 
                                         
                      </div>
                    </td>';
                    echo "</tr>";
                  }
                 else if($r['s_date']>$today )
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $timestamp = strtotime($sts);
                     $sts = date("d/m/Y", $timestamp);
                        
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on <br> '.$sts.'</span>
                    </td>
                    <td></td>
                     <td>
                        <label class="button button1"  name="but1" style="vertical-align:middle"><span> Test will start soon</span></label> </td>
                                         
                      </div>
                    </td>';
                    echo "</tr>";
          
                          }

                      else if(($r['s_date']==$today and $ttt >= $r['s_time']) and ($r['e_date']==$today and $ttt <=$r['e_time'] ))
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $etime=$r['e_time'];
                          $s=$r['s_time'];
                           $timestamp = strtotime($sts);
                        $sts = date("d/m/Y", $timestamp);
                          


                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>

                    <td class="budget">'
                      .$name.'
                    </td>

                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    
                    
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>

                    <td>
                      <span class="status">Scheduled on<br> '.$sts.'</span>
                    </td>
                    <td></td>
                    <td>
                      <div>
                     <button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>start test</span></button> 
                                         
                      </div>
                    </td>';
                    echo "</tr>";
                  }

                  else if( $today > $r['s_date'] and $today <= $r['e_date'])
                  {
                    
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $etime=$r['e_time'];
                           $timestamp = strtotime($sts);
                        $sts = date("d/m/Y", $timestamp);
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name.'
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on<br> '.$sts.'</span>
                    </td>
                    <td></td>
                    
                     <td>
                      <div>
                     <button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>    start test</span></button> 
                     </div> 
                     </td>
                     
                                         
                     
                    ';
                    echo "</tr>";
                 
                  
                  }

                      }

                       }
                      }
                      
                      
                    
				            else
                    {

                      if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);
                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                        if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
					 }
                     $y=mysqli_query($db,$sql);

                     
                       $count=mysqli_num_rows($y);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;
                     if($q!='')
                     {
                       $sql="SELECT * FROM post_ans WHERE ass_no LIKE  '$q%' or ass_name  LIKE  '$q%' or s_date  LIKE  '$q%'  or t_ins  LIKE  '$q%' or status LIKE  '$q%' and e_date <='$today' and e_time<='$ttt' and is_deleted like 'not deleted' ";
                        
					 }

                     $y=mysqli_query($db,$sql);
                         
                 
                     while( $r = mysqli_fetch_assoc($y))
                       {  $aa=$r['ass_no'];

                     $a="select ass_no, un from result where un='$un' and ass_no='$aa' ";
                         if(mysqli_num_rows(mysqli_query($db,$a))==0)
                         {
                           if($r['s_date']==$today and $ttt <= $r['s_time'])
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                        $timestamp = strtotime($sts);
                     $sts = date("d/m/Y", $timestamp);
                        echo ' 
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.' </span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name. '
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on<br> '.$sts.'</span>
                    </td>
                    <td></td>
                     <td>
                   <label class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span> Test will start soon</span></label> </td>
                      </div>
                    </td>';
                    echo "</tr>";
                  }
                 else if($r['s_date']>$today )
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $timestamp = strtotime($sts);
                     $sts = date("d/m/Y", $timestamp);
                        
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name. '
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on <br> '.$sts.'</span>
                    </td>
                    <td></td>
                     <td>
                        <label class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span> Test will start soon</span></label> </td>
                                         
                      </div>
                    </td>';
                    echo "</tr>";
          
                          }

                      else if(($r['s_date']==$today and $ttt >= $r['s_time']) and ( $r['e_date']==$today and $ttt <=$r['e_time']  ))
                          {
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $etime=$r['e_time'];
                           $timestamp = strtotime($sts);
                        $sts = date("d/m/Y", $timestamp);
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name. '
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on<br> '.$sts.'</span>
                    </td>
                    <td></td>
                    
                     <td>
                      <div>
                     <button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>    start test</span></button> </td>
                                         
                      </div>
                    </td>';
                    echo "</tr>";
                  }

                  else if( $today > $r['s_date'] and $today <=$r['e_date'])
                  {
                    
                          $name=$r['ass_name'];
                          $no_qn=$r['no_of_qn'];
                          $duration=$r['tot_time'];
                          $sts=$r['s_date'];
                          $etime=$r['e_time'];
                           $timestamp = strtotime($sts);
                        $sts = date("d/m/Y", $timestamp);
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td class="budget">'
                      .$name. '
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$no_qn.'</span>
                      </span>
                    </td>
                    <td>
                      <span class="status">'.$duration.'</span>
                    </td>
                    <td>
                      <span class="status">Scheduled on<br> '.$sts.'</span>
                    </td>
                    <td></td>
                    
                     <td>
                      <div>
                     <button  class="button button1" value='.$aa.' name="but1" style="vertical-align:middle"><span>    start test</span></button> </td>
                                         
                      </div>
                    </td>';
                    echo "</tr>";
                  
                  }

                     }

                       }
                      }
                      
                  ?>



                      </form> 
				             </tr>
                   </tbody>
                 </table>