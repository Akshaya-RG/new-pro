<?php

session_start();
$a=$_SESSION['uname'];
echo $a;
?>




<!DOCTYPE html>
<html>

<head>
  <style>
img {
  border-radius: 50%;
}

.inv {
    display: none;
}
</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Argon Dashboard - Free Dashboard for Bootstrap 4</title>
  <!-- Favicon -->
  <link rel="icon" href="../assets/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="../assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="../assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <!-- Argon CSS -->
 <link rel="stylesheet" href="../assets/css/argon.css?v=1.2.0" type="text/css">
<style>
body{
	font-family: 'IBM Plex Sans', sans-serif;
	background-image: url(bg.jpg);
	background-size: 100% 100%;
	color: #fff;
}


.tab:not(:checked) + label{
	opacity: 0.8;
}
.login-form{
	position: absolute;
	top: 30%;
	left: 7%;
	right: 10%;
	width: 400px;
}
.tab{
	display: none;
}
.tab-header{
	width: 20%;
	text-align: center;
	display: inline-block;
	font-size: 18px;
	cursor: pointer;
	
}
.tab-header:after{
	display: block;
	content: '';
	height: 20px;
	border-bottom: 2px solid rgb(173,56,120);
	transform: scaleX(0);
	transition: transform 250ms ease-in-out;
}
.tab:checked + label:after{
	transform: scaleX(1);
}
.header{
	margin: 10px 0 10px 0;
	font-size: 20px;
	text-align: center;
	color: rgba(255,255,255,0.8);
}
.form-input input{
	border-radius: 10px;
	height: 35px;
	margin: 10px 450px;
	width: 40%;
	border-width: 0;
	background-color: rgba(255,255,255,0.2);
	padding: 10px;
	color: #fff;
}
input::placeholder, #check{
	color: rgba(255,255,255,0.8);
}
input:focus{
	outline: none;
}
.submit-button{
	margin: 20px 450px;
	width: 40%;
	height: 35px;
	border-radius: 10px;
	border-width: 0;
	text-align: center;
	background-color: rgb(173,56,120);
	color: #fff;
}
input {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: none;
  border-bottom: 2px solid red;
  opacity: 0.6;
  color: white;
}
select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: none;
  border-bottom: 2px solid red;
  opacity: 0.6;
}

.button1 {border-radius: 12px;}

  button {
  background-color: #5e72e4;
  color: white;
  border-radius:12px;
  padding: 14px 14px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.7;
}



/* Set a style for all buttons */
button {
  background-color: #9966ff;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}
</style>













</head>

<body>
  <!-- Sidenav -->
  
 
  <!-- Main content -->
   <div class="container" id="panel">
    <!-- Topnav -->

    <!-- Header -->
    <!-- Header -->


        <form  onsubmit="return validation()" >
            
            <div class="card-body">
             
                <h6 class="heading-small text-muted mb-4">Personal Details</h6>
                <div class="pl-lg-4">
                  <div class="row">

           
                    
                    <div class="col-lg-6">
                      
                        
                        <input type="text" id="fn" class="form-control"    name="fn"  placeholder="FIRST NAME" >
						             <span id="username" class="text-danger font-weight-bold"> </span>               
                                         
					  
                    </div>

                    <div class="col-lg-6">
                      <div class="form-group">
                        
                        <input type="text" id="ln" class="form-control"    name="ln"  placeholder="LAST NAME"  >
						         <span id="lnn" class="text-danger font-weight-bold"> </span>
                      </div>
                    </div>
                      
                    
              
                  
                    
                    <div class="col-lg-6">
                      
                        
                        <input type="date" id="dob" class="form-control"  name="dob"  >
                      
                    </div>


                     <div class="col-lg-6">
                      <div class="form-group">
                        
                        <input type="number" id="phno" class="form-control"   name="phno" placeholder="PHONE NO" >
                       <span id="pnn" class="text-danger font-weight-bold"> </span>   
                      </div>
                    </div>
                      
                    



                    <div class="col-lg-6">
                      <div class="form-group">

                        <div class="select-option">
                              
                           
                               <select id="gen"  class="form-control"   name="gen" id="gen"  >
            <option value="select" selected hidden>gender..</option>
            <option value="male">male</option>
            <option value="female">female</option>
              <option value="others">others</option>
          </select>
             <span id="result" class="text-danger font-weight-bold"> </span>
      
     </div>
   </div>
 </div>

                     

                     


                     <div class="col-lg-6">
                      <div class="form-group">

                        <div class="select-option">
                              
                           
                               <select id="tins"  class="form-control" name="tins"  >
            <option value="select" selected hidden>Select Type of institute</option>
            <option value="school">school</option>
            <option value="clg">college</option>
       
        </select>
  <span id="dis" class="text-danger font-weight-bold"> </span>
      
     </div>
   </div>
 </div>


        <div id="school" class="inv">
              
        <hr class="my-4" />

          <h6 class="heading-small text-muted mb-4">Academic Details</h6>
                <div class="pl-lg-4">
                  <div class="row">

                    <div class="col-lg-6">
                      <div class="form-group">
                        
                      <select id="ins"  class="form-control"   name="ins1" >
            <option value="select"  selected hidden>Select Institution name</option>
            <option value="tvs">tvs</option>
            <option value="vikaasa">vikaasa</option>
           <option value="mahatma">mahatma</option>

       
        </select>
  <span id="dis1" class="text-danger font-weight-bold"> </span>
                      </div>
                    </div>
                  
               

                  
                    <div class="col-lg-6">
                      <div class="form-group">
                        
                        <input id="rno" class="form-control" type="text" name="rno" placeholder="ROLL NO" >
                      </div>
                    </div>
                 
               

                  <div class="col-lg-6">
                      <div class="form-group">
                        
                         <select name="clas"  class="form-control" id="clas">
                                    
                                     <option value="select" selected hidden>class</option>
                                    <option value="11" >XI</option>
                                     <option value="12" >XII</option>
                                 



                                </select>
                   <span id="std1" class="text-danger font-weight-bold"> </span>
                      </div>
                    </div>


                
                    <div class="col-lg-6">
                      <div class="form-group">
                        

                        <select id="gp"  name="gp"  class="form-control" >
                                     <option value="select" selected hidden>group</option>
									                    <option value="cse">cse</option>
                                    <option value="bio" >bio</option>
                                    <option value="commerce" >commerce</option>
                                     
                                </select>
								<span id="gp1" class="text-danger font-weight-bold"> </span>		 
                      </div>
                    </div>
                    
                    
                  </div>
                </div>
               </div>

        


               
               <div id="clg" class="inv">
                <hr class="my-4" />
                 <h6 class="heading-small text-muted mb-4">Academic Details</h6>
                <div class="pl-lg-4">
                  <div class="row">

                    <div class="col-lg-6">
                      <div class="form-group">
                        

                                     <select id="ins"  class="form-control"   name="ins" >
            <option value="select" selected hidden>Select Institution name</option>
            <option value="klnce">klnce</option>
            <option value="klnit">klnit</option>
           

       
        </select>

		  <span id="dis2" class="text-danger font-weight-bold"> </span>


                      </div>
                    </div>
               

                  
               

                  
                    <div class="col-lg-6">
                      <div class="form-group">
                   
                        <input id="rno" class="form-control" type="text" name="rno" placeholder="ROLL NO" >
                      </div>
                    </div>
                 
               

                  <div class="col-lg-6">
                      <div class="form-group">
                        
                        <select id="clas"  name="yr"  class="form-control" >
                                    <option value="select" selected hidden>Year</option>                                   
								                     <option value="1">I</option>
                                    <option value="2" >II</option>
                                    <option value="3" >III</option>
                                    <option value="4" >1V</option>

                                     
                                </select>
								<span id="yr1" class="text-danger font-weight-bold"> </span>
                      </div>
                    </div>


                
                    <div class="col-lg-6">
                      <div class="form-group">
                        
                      <select id="gp"  name="dept"  class="form-control"  >
                                    <option value="select" selected hidden>Department</option>
									                   <option value="CSE">CSE</option>
                                    <option value="IT" >IT</option>
                                    <option value="EEE" >EEE</option>
                                     <option value="ECE" >ECE</option>
                                     <option value="MECH" >MECH</option>
                                        <option value="CIVIL" >CIVIL</option>
                                </select>
								<span id="dep1" class="text-danger font-weight-bold"> </span>
                      </div>
                    </div>
                    
                    
                  </div>
                </div>
              </div>
           


              <script>
            document
                .getElementById('tins')
                .addEventListener('change', function () {
                    'use strict';
                    var vis = document.querySelector('.vis'),   
                     tins = document.getElementById(this.value);
                    if (vis !== null) {
                        vis.className = 'inv';
                    }
                    if (tins !== null ) {
                        tins.className = 'vis';
                    }
            });
        </script>


                
                               </div>
                             </div>
                            
                           
                          </div>
                  
              

                <!-- Address -->

                
               
                <hr class="my-4" />
                <!-- Description -->
               
                
                   
                    <button type="submit" id="submit" class="button button1"  name="submit" style="vertical-align:middle"  onclick='validation();' ><span>submit !!!</span></button> 
                  </div>
                    </div>   
					   </form>

                
              
            </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>      
<script>
function validation(){
	   var lk;
	  lk=val() ;
	  //console.log(lk);
													  
		  
													  if(lk == true)
													  {
														    //console.log(11);
															var fn = $('#fn').val();
															var ln = $('#ln').val();
															var dob= $('#dob').val();
															var phno= $('#phno').val();
															var gen =$('#gen').val();
															var tins=$('#tins').val();
															var ins= $('#ins').val();
															var clas = $('#clas').val();
															var gp = $('#gp').val();
                              var rno=$('#rno').val();

															



															   $.ajax({
																  url:"reg.php",
																  type:"post",
																  data: { 
																	 fn : fn,
																	 ln : ln,
																	 dob : dob,
																	 phno : phno,
																	  gen:gen,
																	 tins:tins,
																	 ins : ins,
																	 clas : clas,
																	 gp : gp,
                                   rno:rno,
																	
																	},
																   
																	success:function(da){
																	   var response = JSON.parse(da);    
																	   console.log(response.statusCode); 
																	   if (response.statusCode=='200') {    
																	   alert("Check in to ur mail for otp");   
																	   }
																		        
																						                           
																	 
																	}


																  });

															   //console.log(rno);
																//console.log(tins);
																 //console.log(fn);
															   
															   

															 }
														
													 
		   



		   
		   
		   
		   	
		   }




       function val()
       {  
        var user = document.getElementById('fn').value;
    var v = document.getElementById('ln').value
    var pn = document.getElementById('phno').value;
    var s1 = document.getElementById('gen').value;
    var t = document.getElementById('tins').value;                            
    
    
    
                                          if(user == ""){
                                             document.getElementById('username').innerHTML = " **FILL the first name field";
                                            return lk = false;
                                               }
                                          if((user.length <= 2)|| (user.length > 20 ))
                                          {
                                              document.getElementById('username').innerHTML = " **FILL the user name length between 1 and 5 field";
                                              return lk = false;
                                                }  
                                          if(!isNaN(user))
                                          {
                                                 document.getElementById('username').innerHTML = " **only char are allowed";
                                                 return lk =  false;
                           
                                                  }
                            
                            
                                                                  if(v == ""){
                                         document.getElementById('lnn').innerHTML = " **FILL the last name field";
                                             return lk =  false;
                                              }     
                                         
                                         if( (v.length > 10 )){
                                              document.getElementById('lnn').innerHTML = " **FILL the user name length within 10";
                                              return lk =  false;
                                                }  
                                         if(!isNaN(v)){
                                                 document.getElementById('lnn').innerHTML = " **only char are allowed";
                                                 return lk =  false;
                                              }
                    
                   



              if(pn == ""){
                              document.getElementById('pnn').innerHTML = " **FILL the phone number field";
                return lk = false;
                            } 
                            if(isNaN(pn)){
                document.getElementById('pnn').innerHTML = " **only digits are allowed";
                return lk = false;
                              }               
              if(pn.length!=10){
                document.getElementById('pnn').innerHTML = " **the phone number must be 10 digit ";
                return lk =  false;
              } 
              
              
          
              
              
        if(s1 == "select")
             {
               document.getElementById('result').innerHTML = "select any";
               return lk = false;
                             
                             }
                     
                                  
            if(t == "select")
                            {
               document.getElementById('dis').innerHTML = "select any";
               return lk =  false;
                             
              }
                                
                  
                  
            else if(t == "school")
            {
                var t1 = document.getElementById('ins').value;
              var s = document.getElementById('clas').value;
              var g = document.getElementById('gp').value;
                
                      if(t1 == "select") 
                      {
                       document.getElementById('dis1').innerHTML = "select any";
                       return lk =  false;
                                     
                      }
                    
                    
                    if(s == "select") 
                      {
                       document.getElementById('std1').innerHTML = "select any";
                       return lk = false;
                                     
                      }
                                 
                                    if(g == "select") 
                      {
                       document.getElementById('gp1').innerHTML = "select any";
                       return lk = false;
                                     
                      }                
            
                
            
            
            
            }
                    else {
       
                        var t2 = document.getElementById('ins').value;
              var y = document.getElementById('clas').value;
              var d = document.getElementById('gp').value;
                 
                          if(t2 == "select") 
                          {
                           document.getElementById('dis2').innerHTML = "select any";
                           return lk = false;
                                         
                          }
                          
                        if(y == "select") 
                          {
                           document.getElementById('yr1').innerHTML = "select any";
                           return lk = false;
                                         
                          } 
                      if(d == "select") 
                          {
                           document.getElementById('dep1').innerHTML = "select any";
                           return lk = false;
                           }
                                         
              
              
              }                           
                            
       }
    
    
    </script>



     
        
      
      


  
      
	  
	  
	  
	  
	  
	  
	  
	  <!-- Footer -->
      
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="../assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Argon JS -->
  <script src="../assets/js/argon.js?v=1.2.0"></script>
</body>

</html>